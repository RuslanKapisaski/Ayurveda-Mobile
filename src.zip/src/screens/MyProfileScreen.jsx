import { useCallback, useState } from "react";
import {
  View,
  Text,
  StyleSheet,
  ScrollView,
  ActivityIndicator,
  TextInput,
  TouchableOpacity,
  Alert,
} from "react-native";
import useAuth from "../contexts/auth/useAuth";
import { formatDate } from "../utils/dateFormater";
import * as userService from "../services/userService";
import HistoryCard from "../components/HistoryCard";
import ThemeButton from "../components/ThemeButton";
import { useTheme } from "../contexts/theme/useTheme";
import { useFocusEffect } from "@react-navigation/native";
import useFetchCount from "../hooks/useFetchCount";
import useFetch from "../hooks/useFetch";
import useFetchUserData from "../hooks/useFetchUserData";
import useFetchAppointmentDetails from "../hooks/useFetchAppointmentDetails";
import { Image } from "expo-image";

export default function ProfileScreen() {
  const { user, logout } = useAuth();
  const { toggleTheme, isDarkMode, setIsDarkMode, theme } = useTheme();

  const [editingAllergies, setEditingAllergies] = useState(false);
  const [logoutLoading, setLogoutLoading] = useState(false);

  const {
    counts,
    loadCount,
    isLoading: countsLoading,
    error: countsError,
  } = useFetchCount(user.id);

  const {
    detailedAppointments,
    loadDetails,
    isLoading: detailsLoading,
    error: detailsError,
  } = useFetchAppointmentDetails(user.id);

  const {
    allergies,
    firestoreUser,
    loadUserData,
    isLoading: userLoading,
    error: userError,
  } = useFetchUserData(user.id);

  useFocusEffect(
    useCallback(() => {
      if (!user?.id) return;
      loadDetails();
      loadCount();
      loadUserData();
    }, [user?.id]),
  );

  const handleEditAllergies = () => {
    if (editingAllergies) {
      const updatedAllergies = allergies.filter((item) => item.trim() !== "");
      userService.setUserAllergies(user.id, updatedAllergies);
    }
    setEditingAllergies(!editingAllergies);
  };

  const handleAddAllergy = () => {
    setAllergies([...allergies, ""]);
  };

  const handleAllergyChange = (index, value) => {
    const updatedAllergies = [...allergies];
    updatedAllergies[index] = value;
    setAllergies(updatedAllergies);
  };

  const handleLogout = () => {
    Alert.alert("Sign Out", "Are you sure you want to sign out?", [
      { text: "Cancel", style: "cancel" },
      {
        text: "Sign Out",
        style: "destructive",
        onPress: async () => {
          try {
            setLogoutLoading(true);
            setIsDarkMode(false);
            await logout();
          } catch (error) {
            console.log("Logout error:", error);
          } finally {
            setLogoutLoading(false);
          }
        },
      },
    ]);
  };

  const isLoading = countsLoading || detailsLoading || userLoading;
  const error = countsError || detailsError || userError;

  if (isLoading) {
    return <ActivityIndicator size="large" style={{ flex: 1 }} />;
  }

  if (error) {
    return <Text style={styles.error}>{error}</Text>;
  }

  return (
    <ScrollView showsVerticalScrollIndicator={false} style={styles.safe}>
      {/* Header */}
      <View style={[styles.header, { backgroundColor: theme.colors.header }]}>
        <Image
          source={{
            uri:
              firestoreUser?.photoURL ||
              "https://img.freepik.com/premium-vector/profile-icon-vector-image-can-be-used-ui_120816-260932.jpg?semt=ais_rp_progressive&w=740&q=80",
          }}
          style={styles.avatar}
          cachePolicy={"memory-disk"}
          transition={200}
        />
        <View>
          <Text style={[styles.welcome, { color: theme.colors.secondary }]}>
            Welcome,{" "}
            <Text style={styles.username}>{firestoreUser.name} 🌿</Text>
          </Text>
        </View>
        <ThemeButton toggleTheme={toggleTheme} isDark={isDarkMode} />
      </View>

      {/* User Information Section */}
      <View style={[styles.card, theme.shadows.medium, { backgroundColor: theme.colors.cardColor }]}>
        <Text style={[styles.cardTitle, { color: theme.colors.text }]}>
          User Information
        </Text>
        {[
          { label: "Active since", value: formatDate(firestoreUser.createdAt) },
          { label: "Name", value: firestoreUser.name },
          { label: "Email", value: firestoreUser.email },
          { label: "Dominant Dosha", value: firestoreUser.dosha?.dominant },
          {
            label: "Dosha Scores",
            value: `Kapha: ${user.dosha?.scores?.Kapha || 0}, Pitta: ${user.dosha?.scores?.Pitta || 0}, Vata: ${user.dosha?.scores?.Vata || 0}`,
          },
        ].map(({ label, value }) => (
          <Text
            key={label}
            style={[
              styles.infoText,
              { color: theme.colors.text, borderColor: theme.colors.text },
            ]}
          >
            {label}: {value || "Not available"}
          </Text>
        ))}
      </View>

      {/* Allergies Section */}
      <View style={[styles.card, theme.shadows.medium,  { backgroundColor: theme.colors.cardColor }]}>
        <Text style={[styles.cardTitle, { color: theme.colors.text }]}>
          Allergies
        </Text>
        {editingAllergies ? (
          allergies.map((allergy, index) => (
            <TextInput
              key={index}
              style={[
                styles.textInput,
                { color: theme.colors.text, borderColor: theme.colors.text },
              ]}
              value={allergy}
              onChangeText={(value) => handleAllergyChange(index, value)}
              placeholder={`Allergy #${index + 1}`}
            />
          ))
        ) : (
          <Text
            style={[
              styles.infoText,
              { color: theme.colors.text, borderColor: theme.colors.text },
            ]}
          >
            {allergies.length > 0
              ? allergies.join(", ")
              : "No allergies listed"}
          </Text>
        )}

        {editingAllergies && (
          <TouchableOpacity style={styles.addButton} onPress={handleAddAllergy}>
            <Text style={styles.addButtonText}>+ Add Allergy</Text>
          </TouchableOpacity>
        )}

        <TouchableOpacity
          onPress={handleEditAllergies}
          style={[styles.editButton, theme.shadows.medium, { backgroundColor: theme.colors.primary }]}
        >
          <Text style={styles.editButtonText}>
            {editingAllergies ? "Save" : "Edit"}
          </Text>
        </TouchableOpacity>
      </View>

      {/* Goals Section */}
      <View style={[styles.card, theme.shadows.medium, { backgroundColor: theme.colors.cardColor }]}>
        <Text style={[styles.cardTitle, { color: theme.colors.text }]}>
          Goals
        </Text>
        {firestoreUser.goals?.length > 0 ? (
          firestoreUser.goals.map((goal, index) => (
            <Text
              key={index}
              style={[
                styles.goalText,
                { color: theme.colors.text, borderColor: theme.colors.text },
              ]}
            >
              {goal}
            </Text>
          ))
        ) : (
          <Text style={{ color: theme.colors.text }}>No goals set</Text>
        )}
      </View>

      {/* History Section */}
      <View style={[styles.card, theme.shadows.medium, { backgroundColor: theme.colors.cardColor }]}>
        <Text style={[styles.cardTitle, { color: theme.colors.text }]}>
          History of appointments
        </Text>
        {detailedAppointments.length > 0 ? (
          detailedAppointments.map((app, index) => (
            <HistoryCard key={index} item={app} formatDate={formatDate} />
          ))
        ) : (
          <Text style={{ color: theme.colors.text }}>No history yet</Text>
        )}
      </View>

      {/* Sign Out Section */}
      <View style={styles.logoutContainer}>
        {logoutLoading ? (
          <ActivityIndicator size="large" />
        ) : (
          <TouchableOpacity
            onPress={handleLogout}
            style={[
              styles.logoutButton,
              theme.shadows.large, 
              { backgroundColor: theme.colors.primary },
            ]}
          >
            <Text style={styles.logoutButtonText}>Sign Out</Text>
          </TouchableOpacity>
        )}
      </View>
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  safe: {
    flex: 1,
  },
  header: {
    paddingTop: 60,
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "space-between",
    paddingVertical: 15,
    paddingHorizontal: 20,
    borderBottomWidth: 1,
  },
  welcome: {
    fontSize: 18,
  },
  username: {
    fontSize: 18,
    fontWeight: "500",
    color: "#f2f8c4",
  },
  avatar: {
    width: 50,
    height: 50,
    borderRadius: 25,
    marginRight: 15,
  },
  card: {
    marginHorizontal: 20,
    marginVertical: 10,
    padding: 20,
    borderRadius: 12,
  },
  cardTitle: {
    fontSize: 18,
    fontWeight: "bold",
    marginBottom: 8,
  },
  infoText: {
    fontSize: 16,
    borderWidth: 1,
    borderRadius: 8,
    marginTop: 6,
    paddingVertical: 10,
    paddingHorizontal: 10,
  },
  textInput: {
    fontSize: 16,
    padding: 8,
    marginTop: 8,
    borderRadius: 8,
    borderWidth: 1,
    borderColor: "#ddd",
    backgroundColor: "#f9f9f9",
  },
  addButton: {
    marginTop: 10,
    paddingVertical: 8,
    paddingHorizontal: 12,
    backgroundColor: "#4A7C59",
    borderRadius: 8,
  },
  addButtonText: {
    color: "#fff",
    textAlign: "center",
    fontSize: 16,
  },
  editButton: {
    marginTop: 10,
    paddingVertical: 8,
    paddingHorizontal: 12,
    borderRadius: 8,
  },
  editButtonText: {
    color: "#fff",
    textAlign: "center",
    fontSize: 16,
  },
  goalText: {
    fontSize: 16,
    marginTop: 8,
    borderWidth: 1,
    paddingVertical: 15,
    paddingHorizontal: 12,
    borderRadius: 8,
  },
  logoutContainer: {
    marginTop: 10,
    marginBottom: 40,
    alignItems: "center",
  },
  logoutButton: {
    paddingVertical: 14,
    paddingHorizontal: 60,
    borderRadius: 12,
  },
  logoutButtonText: {
    color: "#FFF",
    fontSize: 16,
    fontWeight: "600",
  },
  error: {
    color: "#FF0000",
    textAlign: "center",
    fontSize: 18,
    marginTop: 80,
  },
});
