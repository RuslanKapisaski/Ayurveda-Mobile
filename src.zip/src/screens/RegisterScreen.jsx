import { useState } from "react";
import { Platform, StyleSheet, TouchableOpacity } from "react-native";
import { TextInput } from "react-native";
import { Text } from "react-native";
import { KeyboardAvoidingView, View } from "react-native";
import { SafeAreaView } from "react-native-safe-area-context";

import { validate } from "../utils/validate";
import useAuth from "../contexts/auth/useAuth";
import ImagePicker from "../components/ImagePicker";

export default function RegisterScreen({ navigation }) {
  const [username, setUsername] = useState("");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [confirmPassword, setConfirmPassword] = useState("");
  const [errors, setErrors] = useState({});
  const { error, register, clearError } = useAuth();
  const [imageUrl, setImageUrl] = useState(null);

  const handleRegister = () => {
    setErrors({});
    clearError();

    const validationErrors = validate(
      { username, email, password, confirmPassword },
      "register",
    );

    setErrors(validationErrors);

		if (Object.keys(validationErrors).length === 0) {
			register(username, email, password, imageUrl);
		}
	};
	return (
		<SafeAreaView style={styles.container}>
			<KeyboardAvoidingView
				behavior={Platform.OS === "ios" ? "padding" : "height"}
				style={styles.inner}
			>
				<Text style={styles.title}>Register</Text>
				{error && (
					<Text style={styles.error}>
						Registration failed. Please try again later. {error.text}
					</Text>
				)}

        <ImagePicker onImagePicked={setImageUrl} imageUri={imageUrl} />
        <TextInput
          placeholder="Full Name"
          style={styles.input}
          value={username}
          onChangeText={setUsername}
        />
        {errors.username && <Text style={styles.error}>{errors.username}</Text>}
        <TextInput
          placeholder="Email"
          style={styles.input}
          value={email}
          onChangeText={setEmail}
        />
        {errors.email && <Text style={styles.error}>{errors.email}</Text>}
        <TextInput
          placeholder="Password"
          style={styles.input}
          value={password}
          secureTextEntry={true}
          onChangeText={setPassword}
        />
        {errors.password && <Text style={styles.error}>{errors.password}</Text>}
        <TextInput
          placeholder="Confirm password"
          style={styles.input}
          value={confirmPassword}
          secureTextEntry={true}
          onChangeText={setConfirmPassword}
        />
        {errors.confirmPassword && (
          <Text style={styles.error}>{errors.confirmPassword}</Text>
        )}
        <TouchableOpacity style={styles.button} onPress={handleRegister}>
          <Text style={styles.buttonText}>Register</Text>
        </TouchableOpacity>
        <TouchableOpacity onPress={() => navigation.navigate("Login")}>
          <Text style={styles.link}>Already have account?</Text>
        </TouchableOpacity>
      </KeyboardAvoidingView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: "#F6F9F7" },
  inner: {
    flex: 1,
    gap: 10,
    justifyContent: "center",
    padding: 24,
    margin: 20,
  },
  title: {
    fontSize: 28,
    fontWeight: "700",
    marginBottom: 24,
    alignSelf: "center",
  },
  input: {
    backgroundColor: "#fff",
    padding: 20,
    borderRadius: 10,
    marginBottom: 10,
  },
  button: {
    backgroundColor: "#1F3F36",
    padding: 16,
    borderRadius: 10,
    marginTop: 10,
  },
  buttonText: { color: "#fff", textAlign: "center", fontWeight: "600" },
  link: { textAlign: "center", marginTop: 16 },
  error: { color: "red", marginBottom: 8 },
});
